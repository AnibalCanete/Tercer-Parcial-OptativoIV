﻿namespace TercerParcialOptativoIV.Models
{
    public class CuentaModel
    {
        public int idcuenta { get; set; }
        public int idpersona { get; set; }
        public string nombrecuenta { get; set; }
        public string numerocuenta { get; set; }
        public double saldo { get; set; }
        public double limite { get; set; }
        public string moneda { get; set; }
        public string estado { get; set; }

    }
}
