﻿namespace TercerParcialOptativoIV.Models
{
    public class PersonaModel
    {
        public int id { get; set; }
        public string nombre { get; set; }
        public string apellido { get; set; }
        public string tipodocumento { get; set; }
        public string documento { get; set; }
        public string direccion { get; set; }
        public string telefono { get; set; }
        public string mail { get; set; }
        public string estado { get; set; }

    }
}
